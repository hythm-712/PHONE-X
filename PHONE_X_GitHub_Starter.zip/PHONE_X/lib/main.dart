import 'package:flutter/material.dart';

void main() {
  runApp(const PhoneXApp());
}

class PhoneXApp extends StatelessWidget {
  const PhoneXApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'PHONE X',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF080B12),
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFF28C7FA),
          secondary: Color(0xFF4776E6),
          surface: Color(0xFF111824),
        ),
        useMaterial3: true,
        cardTheme: CardThemeData(
          color: const Color(0xFF111824),
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(18),
            side: const BorderSide(color: Color(0xFF202D3D)),
          ),
        ),
      ),
      home: const DashboardScreen(),
    );
  }
}

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  static const _modules = <_ModuleData>[
    _ModuleData(Icons.phone_android, 'معلومات الجهاز', 'Device information'),
    _ModuleData(Icons.health_and_safety_outlined, 'فحص الهاتف', 'Device diagnostics'),
    _ModuleData(Icons.wifi, 'مراقبة الإنترنت', 'Internet monitoring'),
    _ModuleData(Icons.speed, 'مختبر الشبكة', 'Network lab'),
    _ModuleData(Icons.memory, 'الأداء والذاكرة', 'Performance & memory'),
    _ModuleData(Icons.assessment_outlined, 'التقارير والسجل', 'Reports & history'),
  ];

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Text(
            'PHONE X',
            style: TextStyle(fontWeight: FontWeight.w800, letterSpacing: 1.5),
          ),
          centerTitle: false,
          actions: [
            IconButton(
              tooltip: 'الإعدادات',
              onPressed: () {},
              icon: const Icon(Icons.settings_outlined),
            ),
          ],
        ),
        body: SafeArea(
          child: ListView(
            padding: const EdgeInsets.all(18),
            children: [
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(22),
                  gradient: const LinearGradient(
                    colors: [Color(0xFF102B43), Color(0xFF111824)],
                    begin: Alignment.topRight,
                    end: Alignment.bottomLeft,
                  ),
                  border: Border.all(color: const Color(0xFF24516B)),
                ),
                child: const Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'مركز فحص ومراقبة هاتفك',
                      style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                    ),
                    SizedBox(height: 8),
                    Text(
                      'معلومات دقيقة، اختبارات حقيقية، وتقارير واضحة.',
                      style: TextStyle(color: Color(0xFFB7C7D8), height: 1.5),
                    ),
                    SizedBox(height: 18),
                    Row(
                      children: [
                        Icon(Icons.shield_outlined, color: Color(0xFF28C7FA)),
                        SizedBox(width: 8),
                        Text(
                          'تعمل البيانات محلياً في هذا الإصدار التمهيدي',
                          style: TextStyle(fontSize: 11, color: Color(0xFFB7C7D8)),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 22),
              const Text(
                'أدوات PHONE X',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 12),
              GridView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: _modules.length,
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  mainAxisSpacing: 12,
                  crossAxisSpacing: 12,
                  childAspectRatio: 1.18,
                ),
                itemBuilder: (context, index) {
                  final module = _modules[index];
                  return Card(
                    child: InkWell(
                      borderRadius: BorderRadius.circular(18),
                      onTap: () {
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: Text(
                              'قسم ${module.arabicTitle} قيد التطوير.',
                            ),
                          ),
                        );
                      },
                      child: Padding(
                        padding: const EdgeInsets.all(14),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(module.icon, color: const Color(0xFF28C7FA), size: 29),
                            const SizedBox(height: 13),
                            Text(
                              module.arabicTitle,
                              style: const TextStyle(fontWeight: FontWeight.bold),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              module.englishTitle,
                              style: const TextStyle(
                                fontSize: 10,
                                color: Color(0xFF8FA3B8),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  );
                },
              ),
              const SizedBox(height: 20),
              const Center(
                child: Text(
                  'PHONE X  •  Haytham Al-Sulami',
                  style: TextStyle(fontSize: 11, color: Color(0xFF718096)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ModuleData {
  const _ModuleData(this.icon, this.arabicTitle, this.englishTitle);

  final IconData icon;
  final String arabicTitle;
  final String englishTitle;
}
