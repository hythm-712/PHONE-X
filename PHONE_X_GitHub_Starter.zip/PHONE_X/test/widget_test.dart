import 'package:flutter_test/flutter_test.dart';
import 'package:phone_x/main.dart';

void main() {
  testWidgets('PHONE X dashboard renders its identity and modules', (tester) async {
    await tester.pumpWidget(const PhoneXApp());

    expect(find.text('PHONE X'), findsOneWidget);
    expect(find.text('مركز فحص ومراقبة هاتفك'), findsOneWidget);
    expect(find.text('مراقبة الإنترنت'), findsOneWidget);
  });
}
