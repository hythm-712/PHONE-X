# GitHub Copilot instructions — PHONE X

You are working on PHONE X, an Android-first Flutter application owned by Haytham Al-Sulami.

## Before coding
1. Inspect all repository files and current git status.
2. Check whether `android/` exists and inspect its Gradle/Kotlin versions.
3. Check Flutter and Dart versions available in the environment.
4. Do not overwrite or delete existing files without explaining why.
5. Present a concise technical assessment and phased plan before substantial implementation.

## Product requirements
- Flutter/Dart is the primary application layer.
- Kotlin is used only for Android-native capabilities that Flutter plugins or Dart cannot reliably provide.
- Local-first operation; no account or external backend is required for core functionality.
- Arabic and English support, including correct RTL/LTR layout.
- Dark premium interface: black/charcoal surfaces with restrained cyan/blue accents.
- Real measurements only. Never fabricate diagnostic or network statistics.

## Architecture
Use feature-first Clean Architecture where it adds value. Keep UI, domain logic, data sources, and platform integration separated. Prefer small, testable components. Explain any added dependency and avoid unnecessary packages.

Suggested features:
- dashboard
- device_info
- diagnostics
- internet_monitoring
- network_lab
- reports
- settings

## Android and privacy constraints
- Target Android 10 (API 29) or later unless the maintainer approves a change.
- Investigate `NetworkStatsManager` for network usage. Explain Usage Access requirements and device/version limitations.
- Do not claim true real-time monitoring if Android only exposes delayed/bucketed statistics.
- Request permissions only when a feature needs them; handle denial gracefully.
- Do not bypass Android security or restricted APIs.
- Do not claim battery repair, CPU acceleration, or hardware tests that are not actually performed.
- Keep user data local unless the maintainer explicitly approves a network service.

## Workflow
- Work in small phases and keep the app compiling.
- After each phase, run `flutter analyze` and relevant tests.
- Add tests for parsing, calculations, repositories, and UI behavior.
- Report files changed, commands run, results, limitations, and next step.
- Wait for approval before moving to the next major phase.
