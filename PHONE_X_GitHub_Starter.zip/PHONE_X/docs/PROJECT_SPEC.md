# PHONE X — Product and Technical Specification

## Identity
- Product: PHONE X
- Full description: Smart Phone Diagnostics & Monitoring System
- Developer: Haytham Al-Sulami
- Platform: Android first
- UI stack: Flutter + Dart
- Native integration: Kotlin when required
- Local storage: SQLite (select a maintained Flutter SQLite package during implementation)
- Operating model: Offline-first

## Product vision
A single dashboard for understanding a phone's available system information, running genuine user-guided hardware checks, reviewing network usage, diagnosing connectivity, and keeping local diagnostic history.

## Functional modules

### 1. Dashboard
Summary cards for device status, battery, storage, network state, and shortcuts to diagnostic tools. Display unavailable values as unavailable, never as invented values.

### 2. Device information
Manufacturer/model, Android version, device identifiers only where safe and permitted, CPU architecture where accessible, RAM, storage, display information, and battery status.

### 3. Hardware diagnostics
Interactive checks for display/touch, camera, microphone, speaker, vibration, and available sensors. Each test must state whether it is automatic, user-guided, unsupported, or permission-blocked.

### 4. Internet monitoring
Monitor both Wi-Fi and mobile-data usage. Planned views: daily, weekly, monthly, totals, app-level usage where permitted, history, charts, configurable thresholds, and notifications. Investigate Android `NetworkStatsManager`; document special Usage Access flow and limitations. Never promise precise real-time or per-app data on every device.

### 5. Performance
Show only metrics available through supported APIs, such as memory/storage and battery state. Avoid unsupported CPU telemetry and misleading performance scores.

### 6. Network lab
Connectivity checks, latency/ping where feasible, connection type, available IP details, and legitimate speed testing. Speed testing requires an active internet connection and a clearly identified test endpoint/service.

### 7. Full device scan
Run available checks and produce statuses: Healthy, Needs Attention, Not Tested, Unable to Test. A status must be backed by a real measurement or completed test.

### 8. Reports and history
Persist diagnostic sessions and usage summaries locally. Provide daily/weekly/monthly views and PDF export.

### 9. Settings
Language, theme, notification preferences, usage thresholds, privacy information, and permission status.

## Initial screen map
1. Splash
2. Dashboard
3. Device Information
4. Battery
5. Storage & RAM
6. Hardware Diagnostics
7. Camera/Audio/Sensors tests
8. Internet Monitoring
9. Network Lab
10. Full Device Scan
11. Reports & History
12. Settings

## Design direction
Premium, restrained technology aesthetic: black/charcoal backgrounds, cyan/blue accents, legible typography, clean cards, accessible contrast, subtle animation, responsive layouts, Arabic RTL and English LTR.

## Non-goals and honesty requirements
PHONE X must not claim to repair batteries, magically accelerate processors, clean memory in a way Android does not support, bypass permissions, or inspect inaccessible hardware. Explain platform and manufacturer limitations in the UI where relevant.
